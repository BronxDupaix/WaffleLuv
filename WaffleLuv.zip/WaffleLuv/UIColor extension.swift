//
//  UIColor extension.swift
//  WaffleLuv
//
//  Created by Bronson Dupaix on 4/7/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import Foundation

struct MyColors{
    
    
    static var getCustomPurpleColor = {
        
        return UIColor(red:0.6, green:0.18 , blue:1.00, alpha:0.6)
        
    }
    
    static var getCustomCyanColor = {
        
        return UIColor(red:1.00, green:0.93, blue:0.75, alpha:1.00)
    }
    
    static var getCustomPinkColor = {
        return UIColor(red:1.0, green:0.4 ,blue:0.78 , alpha:1.00) }
    
    static var getCustomRedColor = {
        
        return UIColor(red:1.0, green:0.00, blue:0.00, alpha:1.00)
    }
    
    static var getCustomCreamColor = {
        
        return UIColor(red:0.9, green:0.9, blue:1.00, alpha:1.00)
    }
    
    static var getCustomBananaColor = {
        
        return UIColor(red:1.00, green:0.93, blue:0.75, alpha:1.00)
    }
    
}
