//
//  BuildYourOwnTableViewCell.swift
//  WaffleLuv
//
//  Created by Bronson Dupaix on 4/12/16.
//  Copyright © 2016 Bronson Dupaix. All rights reserved.
//

import UIKit

class BuildYourOwnTableViewCell: UITableViewCell {


}
